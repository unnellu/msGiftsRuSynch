<?php

/**
 * Class msop2MainController
 */
abstract class msop2MainController extends modExtraManagerController {
	/** @var msop2 $msop2 */
	public $msop2;
	public $miniShop2;

	/**
	 * @return void
	 */
	public function initialize() {
		if (!include_once MODX_CORE_PATH . 'components/minishop2/model/minishop2/minishop2.class.php') {
			throw new Exception('msOptionsPrice requires installed miniShop2.');
		}

		$corePath = $this->modx->getOption('msop2_core_path', null, $this->modx->getOption('core_path') . 'components/msop2/');
		require_once $corePath . 'model/msop2/msop2.class.php';

		$this->msop2 = new msop2($this->modx);
		//$this->miniShop2 = new miniShop2($this->modx);

		$this->addCss($this->msop2->config['cssUrl'] . 'mgr/main.css');
		$this->addJavascript($this->msop2->config['jsUrl'] . 'mgr/msop2.js');
		$this->addHtml('
		<script type="text/javascript">
			msop2.config = ' . $this->modx->toJSON($this->msop2->config) . ';
			msop2.config.connector_url = "' . $this->msop2->config['connectorUrl'] . '";
		</script>
		');

		parent::initialize();
	}


	/**
	 * @return array
	 */
	public function getLanguageTopics() {
		return array('msop2:default');
	}


	/**
	 * @return bool
	 */
	public function checkPermissions() {
		return true;
	}
}


/**
 * Class IndexManagerController
 */
class IndexManagerController extends msop2MainController {

	/**
	 * @return string
	 */
	public static function getDefaultController() {
		return 'home';
	}
}