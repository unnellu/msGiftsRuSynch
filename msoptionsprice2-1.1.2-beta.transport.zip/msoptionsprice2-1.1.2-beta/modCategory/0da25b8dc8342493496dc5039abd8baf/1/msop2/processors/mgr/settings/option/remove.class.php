<?php

class msop2OptionRemoveProcessor extends modObjectRemoveProcessor  {
	public $classKey = 'msop2Option';
	public $languageTopics = array('msop2:default','msop2:manager');
	public $permission = 'msop2setting_save';
	/** {@inheritDoc} */
	public function initialize() {
		if (!$this->modx->hasPermission($this->permission)) {
			return $this->modx->lexicon('access_denied');
		}
		return parent::initialize();
	}
}
return 'msop2OptionRemoveProcessor';