<?php

class msop2OptionGetListProcessor extends modObjectGetListProcessor
{
	public $classKey = 'msop2Option';
	public $defaultSortField = 'rank';
	public $defaultSortDirection = 'asc';
	public $languageTopics = array('msop2:default', 'msop2:manager');
	public $permission = 'msop2setting_list';

	/** {@inheritDoc} */
	public function initialize()
	{
		if (!$this->modx->hasPermission($this->permission)) {
			return $this->modx->lexicon('access_denied');
		}
		return parent::initialize();
	}

	/**
	 * @param xPDOQuery $c
	 *
	 * @return xPDOQuery
	 */
	public function prepareQueryBeforeCount(xPDOQuery $c)
	{
		$c->where(array('active' => 1));

		$option = $this->getProperty('option', 0);
		if (!empty($option)) {
			$c->andCondition(array('id' => $option));
		}

		return $c;
	}

	/**
	 * @param xPDOObject $object
	 *
	 * @return array
	 */
	public function prepareRow(xPDOObject $object)
	{
		$array = $object->toArray();

		return $array;
	}

	/** {@inheritDoc} */
	public function outputArray(array $array, $count = false)
	{
		if ($this->getProperty('addall')) {
			$array = array_merge_recursive(array(array(
				'id' => 0,
				'name' => $this->modx->lexicon('msop2_all'),
				'key' => 'all'
			)), $array);
		}
		return parent::outputArray($array, $count);
	}

}

return 'msop2OptionGetListProcessor';