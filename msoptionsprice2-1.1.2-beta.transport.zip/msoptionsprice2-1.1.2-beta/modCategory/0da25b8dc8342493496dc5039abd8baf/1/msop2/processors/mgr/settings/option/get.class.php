<?php
class msop2OptionGetProcessor extends modObjectGetProcessor {
	public $classKey = 'msop2Option';
	public $languageTopics = array('msop2:default','msop2:manager');
	public $permission = 'msop2setting_view';

	/** {@inheritDoc} */
	public function initialize() {
		if (!$this->modx->hasPermission($this->permission)) {
			return $this->modx->lexicon('access_denied');
		}
		return parent::initialize();
	}
	/** {@inheritDoc} */
	public function cleanup() {
		$array = $this->object->toArray();

		return $this->success('', $array);
	}
}
return 'msop2OptionGetProcessor';