<?php

class msop2OptionCreateProcessor extends modObjectCreateProcessor {
	public $classKey = 'msop2Option';
	public $languageTopics = array('msop2:default','msop2:manager');
	public $permission = 'msop2setting_save';
	/** {@inheritDoc} */
	public function initialize() {
		if (!$this->modx->hasPermission($this->permission)) {
			return $this->modx->lexicon('access_denied');
		}
		return parent::initialize();
	}
	/** {@inheritDoc} */
	public function beforeSet() {
		if ($this->modx->getObject('msop2Option',array(
			'key' => $this->getProperty('key'),
		))) {
			return $this->modx->lexicon('msop2_err_non_key_unique');
		}
		return !$this->hasErrors();
	}
	/** {@inheritDoc} */
	public function beforeSave() {
		$this->object->fromArray(array(
			'rank' => $this->modx->getCount('msop2Option'),
			'active' => true
		));
		// remains
		if($this->modx->msop2->getRemainsOption() > 0){
			$this->object->fromArray(array(
				'remains' => 0
			));
		}
		// weight
		if($this->modx->msop2->getWeightOption() > 0){
			$this->object->fromArray(array(
				'weight' => 0
			));
		}
		// article
		if($this->modx->msop2->getArticleOption() > 0){
			$this->object->fromArray(array(
				'article' => 0
			));
		}

		return parent::beforeSave();
	}
}
return 'msop2OptionCreateProcessor';