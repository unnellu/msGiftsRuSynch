<?php

class msop2PriceCreateProcessor extends modObjectCreateProcessor {
	public $classKey = 'msop2Price';
	public $languageTopics = array('msop2:default','msop2:manager');
	public $permission = 'msop2setting_save';
	/** {@inheritDoc} */
	public function initialize() {
		if (!$this->modx->hasPermission($this->permission)) {
			return $this->modx->lexicon('access_denied');
		}
		return parent::initialize();
	}
	/** {@inheritDoc} */
	public function beforeSet() {
		if ($this->modx->getObject('msop2Price',array(
			'product_id' => $this->getProperty('product_id'),
			'option' => $this->getProperty('option'),
			'value' => $this->getProperty('value'),
		))) {
			return $this->modx->lexicon('msop2_err_non_unique');
		}
		return !$this->hasErrors();
	}
	/** {@inheritDoc} */
	public function beforeSave() {
		$c = $this->modx->newQuery('msop2Price');
		$c->where(array(
			'product_id' => $this->getProperty('product_id'),
		));

		$this->object->fromArray(array(
			'rank' => $this->modx->getCount('msop2Price', $c),
			'active' => true
		));

		return parent::beforeSave();
	}
}
return 'msop2PriceCreateProcessor';