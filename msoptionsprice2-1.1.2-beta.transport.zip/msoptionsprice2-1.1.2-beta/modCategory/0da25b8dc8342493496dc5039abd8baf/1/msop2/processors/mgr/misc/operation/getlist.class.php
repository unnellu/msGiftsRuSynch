<?php

class msop2OperationGetListProcessor extends modObjectGetListProcessor {
	public $classKey = 'msop2Operation';
	public $defaultSortField = 'rank';
	public $defaultSortDirection  = 'asc';
	public $languageTopics = array('msop2:default','msop2:manager');
	public $permission = 'msop2setting_list';
	/** {@inheritDoc} */
	public function initialize() {
		if (!$this->modx->hasPermission($this->permission)) {
			return $this->modx->lexicon('access_denied');
		}
		return parent::initialize();
	}
	/**
	 * @param xPDOQuery $c
	 *
	 * @return xPDOQuery
	 */
	public function prepareQueryBeforeCount(xPDOQuery $c) {
		$c->where(array('active' => 1));
		return $c;
	}

	/**
	 * @param xPDOObject $object
	 *
	 * @return array
	 */
	public function prepareRow(xPDOObject $object) {
		$array = $object->toArray();

		return $array;
	}

}

return 'msop2OperationGetListProcessor';