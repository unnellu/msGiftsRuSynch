<?php

class msop2OptionUpdateProcessor extends modObjectUpdateProcessor {
	public $classKey = 'msop2Option';
	public $languageTopics = array('msop2:default','msop2:manager');
	public $permission = 'msop2setting_save';
	/** {@inheritDoc} */
	public function initialize() {
		if (!$this->modx->hasPermission($this->permission)) {
			return $this->modx->lexicon('access_denied');
		}
		return parent::initialize();
	}
	/** {@inheritDoc} */
	public function beforeSet() {
		if ($this->modx->getObject('msop2Option',array('name' => $this->getProperty('name'), 'id:!=' => $this->getProperty('id') ))) {
			$this->modx->error->addField('name', $this->modx->lexicon('msop2_err_non_name_unique'));
		}
		if ($this->modx->getObject('msop2Option',array('key' => $this->getProperty('key'), 'id:!=' => $this->getProperty('id') ))) {
			$this->modx->error->addField('key', $this->modx->lexicon('msop2_err_non_key_unique'));
		}
		// remains
		if($this->getProperty('remains')) {
			if($this->modx->msop2->getRemainsOption() > 0){
				$this->unsetProperty('remains');
			}
		}
		// weight
		if($this->getProperty('weight')) {
			if($this->modx->msop2->getWeightOption() > 0){
				$this->unsetProperty('weight');
			}
		}
		// article
		if($this->getProperty('article')) {
			if($this->modx->msop2->getArticleOption() > 0){
				$this->unsetProperty('article');
			}
		}

		return parent::beforeSet();
	}
}
return 'msop2OptionUpdateProcessor';