<?php

class msop2PriceUpdateProcessor extends modObjectUpdateProcessor {
	public $classKey = 'msop2Price';
	public $languageTopics = array('msop2:default','msop2:manager');
	public $permission = 'msop2setting_save';
	/** {@inheritDoc} */
	public function initialize() {
		if (!$this->modx->hasPermission($this->permission)) {
			return $this->modx->lexicon('access_denied');
		}
		return parent::initialize();
	}
	/** {@inheritDoc} */
	public function beforeSet() {
		if ($this->modx->getObject('msop2Price',array(
			'product_id' => $this->getProperty('product_id'),
			'operation' => $this->getProperty('operation'),
			'value' => $this->getProperty('value'),
			'id:!=' => $this->getProperty('id')

		))) {
			$this->modx->error->addField('name', $this->modx->lexicon('msop2_err_non_name_unique'));
		}

		if ($price = $this->getProperty('price')) {
			$price = preg_replace(array('/[^0-9%\-,\.]/','/,/'), array('', '.'), $price);
			if (strpos($price, '%') !== false) {
				if($this->getProperty('operation') == 1) {
					$price = str_replace('%', '', $price);
				}
				else {
					$price = str_replace('%', '', $price) . '%';
				}
			}
			if (empty($price)) {$price = '0';}
			$this->setProperty('price', $price);
		}
		// remains
		$remains_id = (int) $this->modx->msop2->getRemainsOption();
		$option = (int) $this->getProperty('option', $this->getProperty('option_'));

		if($this->getProperty('count') && ($option !== $remains_id)) {
			$this->unsetProperty('count');
		}
		// option
		$this->unsetProperty('option');

		return parent::beforeSet();
	}
}
return 'msop2PriceUpdateProcessor';