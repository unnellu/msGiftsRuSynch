<?php

class msop2PriceActiveProcessor extends modObjectProcessor {
	public $classKey = 'msop2Price';
	/** {@inheritDoc} */
	public function process() {

		$id = $this->getProperty('id',null);
		if (empty($id)) {
			return $this->success();
		}
		$value = $this->getProperty('value',0);

		$operation = $this->getProperty('operation',1);
		if (empty($operation)) {
			return $this->success();
		}

		if ($price = $this->modx->getObject('msop2Price',
			array(
				'id' => $id,
			))) {
			$price->set('price', $value);
			$price->set('operation', $operation);
			$price->save();
		}

		return $this->success();
	}

}
return 'msop2PriceActiveProcessor';