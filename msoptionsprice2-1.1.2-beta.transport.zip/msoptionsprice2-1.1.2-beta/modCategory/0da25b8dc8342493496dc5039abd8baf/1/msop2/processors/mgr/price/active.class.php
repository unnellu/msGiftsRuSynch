<?php

class msop2PriceActiveProcessor extends modObjectProcessor {
	public $classKey = 'msop2Price';
	/** {@inheritDoc} */
	public function process() {

		$id = $this->getProperty('id',null);
		if (empty($id)) {
			return $this->success();
		}
		$value = $this->getProperty('value',0);

		if ($price = $this->modx->getObject('msop2Price',$id)) {
			$price->set('active', $value);
			$price->save();
		}

		return $this->success();
	}

}
return 'msop2PriceActiveProcessor';