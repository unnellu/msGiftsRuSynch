<?php

class msop2WebGetPriceProcessor extends modProcessor
{

	public function process()
	{

		$data = $this->getProperties();
		$data = $data['data'];
		if (empty($data)) {
			return $this->failure('');
		}
		$msop2 = $this->modx->msop2;
		//
		if (!$id = $data['id']) {
			return $this->failure('');
		}
		if (!$msop2->active) {
			return $this->failure('');
		}
		if (!$product = $this->modx->getObject('msProduct', $id)) {
			return $this->failure('');
		}
		//
		$options = array();
		foreach ($data as $k => $v) {
			if (strpos($k, 'options.') === false) {
				continue;
			}
			if (is_array($v)) {
				continue;
			}
			$option = preg_replace(array('/options./'), array(''), $k);
			$options[$option] = $v;
		}
		//$this->modx->log(1, print_r($options ,1));

		/* price */
		$price = $msop2->getPrice($id, $options);
		if ($msop2->msDiscount) {
			if ($discount_price = $msop2->msDiscount->getNewPrice($id, $price)) {
				$price = $discount_price;
			}
		}
		$data['price'] = $msop2->formatPrice($price);

		/* weight */
		$weight = $msop2->getWeight($id, $options);
		$data['weight'] =$msop2->formatWeight($weight);

		/* article */
		$data['article'] = $msop2->getArticle($id, $options);

		return $msop2->success('ОК', $data, array());
	}

}

return 'msop2WebGetPriceProcessor';