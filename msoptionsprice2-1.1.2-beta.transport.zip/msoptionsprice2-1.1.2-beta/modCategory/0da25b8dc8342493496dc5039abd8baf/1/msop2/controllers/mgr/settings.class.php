<?php

require_once dirname(dirname(dirname(__FILE__))) . '/index.class.php';

class ControllersSettingsManagerController extends msop2MainController {

	public static function getDefaultController() {
		return 'settings';
	}

}

class msop2SettingsManagerController extends msop2MainController {

	public function getPageTitle() {
		return $this->modx->lexicon('msop2') . ' :: ' . $this->modx->lexicon('msop2_settings');
	}

	public function getLanguageTopics() {
		return array('msop2:default','msop2:manager');
	}

	public function loadCustomCssJs() {
		$this->addJavascript(MODX_MANAGER_URL . 'assets/modext/util/datetime.js');
		$this->addJavascript($this->msop2->config['jsUrl'] . 'mgr/misc/utils.js');
		$this->addJavascript($this->msop2->config['jsUrl'] . 'mgr/misc/msop2.combo.js');

		$this->addJavascript($this->msop2->config['jsUrl'] . 'mgr/settings/option.grid.js');
		$this->addJavascript($this->msop2->config['jsUrl'] . 'mgr/settings/operation.grid.js');
		$this->addJavascript($this->msop2->config['jsUrl'] . 'mgr/settings/settings.panel.js');

		//
		$this->addHtml(str_replace('			', '', '
			<script type="text/javascript">


				Ext.onReady(function() {
					MODx.load({ xtype: "msop2-page-settings"});
				});

			</script>'
		));
	}

	public function getTemplateFile() {
		return $this->msop2->config['templatesPath'] . 'mgr/settings.tpl';
	}

}

// MODX 2.3
class ControllersMgrSettingsManagerController extends ControllersSettingsManagerController {

	public static function getDefaultController() {
		return 'mgr/settings';
	}

}

class msop2MgrSettingsManagerController extends msop2SettingsManagerController {

}
