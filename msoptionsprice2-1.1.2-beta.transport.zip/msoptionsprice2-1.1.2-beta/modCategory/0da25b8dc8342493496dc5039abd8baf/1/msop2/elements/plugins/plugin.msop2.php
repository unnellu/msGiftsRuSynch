<?php

$msop2 = $modx->getService('msop2', 'msop2', $modx->getOption('msop2_core_path', null, $modx->getOption('core_path') . 'components/msop2/') . 'model/msop2/', $scriptProperties);
if (!($msop2 instanceof msop2)) return '';

$eventName = $modx->event->name;
if (method_exists($msop2, $eventName) && $msop2->active) {
	$msop2->$eventName($scriptProperties, $product);
}