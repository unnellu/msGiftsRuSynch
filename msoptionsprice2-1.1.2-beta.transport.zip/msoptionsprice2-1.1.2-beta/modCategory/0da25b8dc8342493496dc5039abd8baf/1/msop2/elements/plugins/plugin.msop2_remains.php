<?php
$msop2 = $modx->getService('msop2', 'msop2', $modx->getOption('msop2_core_path', null, $modx->getOption('core_path') . 'components/msop2/') . 'model/msop2/', $scriptProperties);
if (!($msop2 instanceof msop2)) return '';
//
$modx->lexicon->load('msop2:manager');
//
switch ($modx->event->name) {

	case 'msOnBeforeAddToCart':

		if(empty($count)) {return;}
		if($options =='[]') {return;}
		//
		$id = $product->get('id');
		$_remains = $msop2->getRemainsOption();
		//
		if(!$_option = $modx->getObject('msop2Option', $_remains)) {return;}
		$_key = $_option->get('key');
		if(!$_value = $options[$_key]) {return;}
		//
		$_count = $msop2->getRemainsCount(array(
			'product_id' => $id,
			'option' => $_remains,
			'value' => $_value,
		));
		//
		if ($count > $_count)  {
			$modx->event->output($modx->lexicon('msop2_available_count') . $_count . $modx->lexicon('msop2_pieces'));
		}
		if(($cart_items = $cart->get())) {
			// all count
			foreach($cart_items as $item ) {
				$_options = $item['options'];
				if($_options == '[]') {continue;}

				if (($item['id'] == $id) && ($_options[$_key] == $_value)) {
					$_count -= $item['count'];
				}
			}
			if(($count > $_count)) {
				$modx->event->output($modx->lexicon('msop2_available_count_no'));
			}
		}
		break;


	case 'msOnBeforeChangeInCart':

		if (empty($count)) {return;}
		if ($cart_items = $cart->get()) {
			if(!empty($cart_items[$key])) {
				if($cart_items[$key]['options'] =='[]') {return;}
				$id = $cart_items[$key]['id'];
				$_remains = $msop2->getRemainsOption();
				//
				if(!$_option = $modx->getObject('msop2Option', $_remains)) {return;}
				$_key = $_option->get('key');
				//
				if(!$_value = $cart_items[$key]['options'][$_key]) {return;}
				//
				$_count = $msop2->getRemainsCount(array(
					'product_id' => $id,
					'option' => $_remains,
					'value' => $_value,
				));
				// all count
				foreach($cart_items as $item ) {
					$_options = $item['options'];
					if($_options == '[]') {continue;}

					if (($item['id'] == $id) && ($_options[$_key] == $_value)) {
						$_count -= $item['count'];
					}
				}
				if(($count - $cart_items[$key]['count']) > ($_count)) {
					$modx->event->output($modx->lexicon('msop2_available_count_no'));
				}
			}
		}
		break;

	case 'msOnCreateOrder':

		if(!$products = $msOrder->getMany('Products')) {return;}
		$_remains = $msop2->getRemainsOption();
		if(!$_option = $modx->getObject('msop2Option', $_remains)) {return;}
		$_key = $_option->get('key');
		//
		foreach($products as $product) {
			$product_id = $product->get('product_id');
			$options = $product->get('options');
			$count = $product->get('count');
			if($options =='[]') {continue;}
			if(!$_value = $options[$_key]) {continue;}
			//
			if(!empty($arr['count'][$product_id][$_value])) {
				$arr['count'][$product_id][$_value]['count'] += $count;
			}
			else {
				$arr['count'][$product_id][$_value] = array(
					'product_id' => $product_id,
					'option' => $_remains,
					'value' => $_value,
					'count' => $count,
				);
			}
		}
		//
		$msOrder->set('properties', $modx->toJSON($arr));
		if($msOrder->save()) {
			if (!empty($arr)) {
				foreach ($arr['count'] as $products) {
					foreach($products as $k => $v) {
						$_count = $v['count'];
						unset($v['count']);
						if ($_price = $modx->getObject('msop2Price', $v)) {
							$old_count = $_price->get('count');
							$_price->set('count', $old_count - $_count);
							$_price->save();
						}
					}
				}
			}
		}

		break;


	case 'msOnChangeOrderStatus':

		if(empty($status) || $status != 4) {return;}
		$arr = $order->get('properties');
		if(empty($arr['count'])) {return;}
		//
		foreach ($arr['count'] as $products) {
			foreach($products as $k => $v) {
				$_count = $v['count'];
				unset($v['count']);
				if ($_price = $modx->getObject('msop2Price', $v)) {
					$old_count = $_price->get('count');
					$_price->set('count', $old_count + $_count);
					$_price->save();
				}
			}
		}

		break;

}