<?php
/** @var array $scriptProperties */
/** @var msop2 $msop2 */
$msop2 = $modx->getService('msop2', 'msop2', $modx->getOption('msop2_core_path', null, $modx->getOption('core_path') . 'components/msop2/') . 'model/msop2/', $scriptProperties);
if (!($msop2 instanceof msop2)) return 'Could not load msop2 class!';

$msop2->initialize($modx->context->key);

return '';