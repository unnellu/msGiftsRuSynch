<?php
require_once (dirname(dirname(__FILE__)) . '/msop2price.class.php');
class msop2Price_mysql extends msop2Price {}