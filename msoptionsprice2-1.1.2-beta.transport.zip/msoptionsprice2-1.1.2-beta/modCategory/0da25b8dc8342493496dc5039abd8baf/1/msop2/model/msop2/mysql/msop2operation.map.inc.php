<?php
$xpdo_meta_map['msop2Operation']= array (
  'package' => 'msop2',
  'version' => '1.1',
  'table' => 'msop2_operation',
  'extends' => 'xPDOSimpleObject',
  'fields' => 
  array (
    'name' => NULL,
    'description' => NULL,
    'color' => '000000',
    'rank' => 0,
    'active' => 1,
    'editable' => 1,
  ),
  'fieldMeta' => 
  array (
    'name' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '255',
      'phptype' => 'string',
      'null' => false,
    ),
    'description' => 
    array (
      'dbtype' => 'text',
      'phptype' => 'string',
      'null' => true,
    ),
    'color' => 
    array (
      'dbtype' => 'char',
      'precision' => '6',
      'phptype' => 'string',
      'null' => true,
      'default' => '000000',
    ),
    'rank' => 
    array (
      'dbtype' => 'tinyint',
      'precision' => '1',
      'attributes' => 'unsigned',
      'phptype' => 'integer',
      'null' => true,
      'default' => 0,
    ),
    'active' => 
    array (
      'dbtype' => 'tinyint',
      'precision' => '1',
      'attributes' => 'unsigned',
      'phptype' => 'integer',
      'null' => true,
      'default' => 1,
    ),
    'editable' => 
    array (
      'dbtype' => 'tinyint',
      'precision' => '1',
      'phptype' => 'integer',
      'null' => true,
      'default' => 1,
    ),
  ),
  'aggregates' => 
  array (
    'Price' => 
    array (
      'class' => 'msop2Price',
      'local' => 'id',
      'foreign' => 'operation',
      'cardinality' => 'many',
      'owner' => 'local',
    ),
  ),
);
