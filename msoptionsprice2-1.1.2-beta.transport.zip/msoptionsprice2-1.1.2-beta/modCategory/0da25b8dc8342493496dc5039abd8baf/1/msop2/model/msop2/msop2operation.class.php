<?php
class msop2Operation extends xPDOSimpleObject {}