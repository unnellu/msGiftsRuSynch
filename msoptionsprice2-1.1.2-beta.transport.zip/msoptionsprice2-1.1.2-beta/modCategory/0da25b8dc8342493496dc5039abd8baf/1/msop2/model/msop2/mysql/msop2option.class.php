<?php
require_once (dirname(dirname(__FILE__)) . '/msop2option.class.php');
class msop2Option_mysql extends msop2Option {}