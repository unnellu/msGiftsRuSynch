<?php
class msop2Option extends xPDOSimpleObject {

	/** {@inheritdoc} */
	public function remove(array $ancestors= array ()) {
		$id = $this->get('id');
		$table = $this->xpdo->getTableName('msop2Price');
		$sql = "DELETE FROM {$table} WHERE `option` = '$id';";
		$this->xpdo->exec($sql);

		return parent::remove();
	}

}