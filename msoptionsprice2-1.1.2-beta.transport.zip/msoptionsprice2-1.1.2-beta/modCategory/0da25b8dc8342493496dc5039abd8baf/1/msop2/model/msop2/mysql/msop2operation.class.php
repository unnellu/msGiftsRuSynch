<?php
require_once (dirname(dirname(__FILE__)) . '/msop2operation.class.php');
class msop2Operation_mysql extends msop2Operation {}