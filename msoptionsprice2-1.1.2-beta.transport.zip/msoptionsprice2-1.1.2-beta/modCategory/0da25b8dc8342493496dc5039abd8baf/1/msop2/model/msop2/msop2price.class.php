<?php
class msop2Price extends xPDOSimpleObject {}