<?php

/**
 * The base class for msop2.
 */
class msop2
{
	/* @var modX $modx */
	public $modx;
	public $namespace = 'msop2';
	public $cache = null;
	public $config = array();
	public $initialized = array();
	public $active = false;
	public $ms2;
	public $msDiscount;

	/**
	 * @param modX $modx
	 * @param array $config
	 */
	function __construct(modX &$modx, array $config = array())
	{
		$this->modx =& $modx;

		$this->namespace = $this->getOption('namespace', $config, 'msop2');
		$corePath = $this->modx->getOption('msop2_core_path', $config, $this->modx->getOption('core_path') . 'components/msop2/');
		$assetsUrl = $this->modx->getOption('msop2_assets_url', $config, $this->modx->getOption('assets_url') . 'components/msop2/');
		$connectorUrl = $assetsUrl . 'connector.php';

		$this->config = array_merge(array(
			'assetsUrl' => $assetsUrl,
			'cssUrl' => $assetsUrl . 'css/',
			'jsUrl' => $assetsUrl . 'js/',
			'imagesUrl' => $assetsUrl . 'images/',
			'connectorUrl' => $connectorUrl,

			'corePath' => $corePath,
			'modelPath' => $corePath . 'model/',
			'chunksPath' => $corePath . 'elements/chunks/',
			'templatesPath' => $corePath . 'elements/templates/',
			'chunkSuffix' => '.chunk.tpl',
			'snippetsPath' => $corePath . 'elements/snippets/',
			'processorsPath' => $corePath . 'processors/',

			'json_response' => true,
			'webconnector' => $assetsUrl . 'web-connector.php',
			'frontend_css' => $this->modx->getOption('msop2_frontend_css', null, '[[+assetsUrl]]css/web/default.css'),
			'frontend_js' => $this->modx->getOption('msop2_frontend_js', null, '[[+assetsUrl]]js/web/default.js'),

			'cache_key' => $this->namespace . '/',

		), $config);

		$this->modx->addPackage('msop2', $this->config['modelPath']);
		$this->modx->lexicon->load('msop2:default');
		$this->active = $this->modx->getOption('msop2_active', $config, false);

		if (!$this->ms2 = $modx->getService('miniShop2')) {
			$this->modx->log(modX::LOG_LEVEL_ERROR, 'msOptionsPrice2 requires installed miniShop2.');
			return false;
		}
		// msDiscount
		$level = $modx->getLogLevel();
		$modx->setLogLevel(xPDO::LOG_LEVEL_FATAL);
		if ($this->msDiscount = $modx->getService('msDiscount')) {
			if (!($this->msDiscount instanceof msDiscount)) {
				$this->msDiscount = false;
			}
		}
		$modx->setLogLevel($level);

	}

	/**
	 * @param $key
	 * @param array $config
	 * @param null $default
	 * @return mixed|null
	 */
	public function getOption($key, $config = array(), $default = null)
	{
		$option = $default;
		if (!empty($key) && is_string($key)) {
			if ($config != null && array_key_exists($key, $config)) {
				$option = $config[$key];
			} elseif (array_key_exists($key, $this->config)) {
				$option = $this->config[$key];
			} elseif (array_key_exists("{$this->namespace}.{$key}", $this->modx->config)) {
				$option = $this->modx->getOption("{$this->namespace}.{$key}");
			}
		}
		return $option;
	}

	/**
	 * Initializes msOptionsPrice into different contexts.
	 *
	 * @param string $ctx The context to load. Defaults to web.
	 * @param array $scriptProperties array with additional parameters
	 *
	 * @return boolean
	 */
	public function initialize($ctx = 'web', $scriptProperties = array())
	{
		$this->config = array_merge($this->config, $scriptProperties);
		$this->config['ctx'] = $ctx;
		if (!empty($this->initialized[$ctx])) {
			return true;
		}
		switch ($ctx) {
			case 'mgr':
				break;
			default:
				if (!defined('MODX_API_MODE') || !MODX_API_MODE) {
					if ($css = trim($this->config['frontend_css'])) {
						if (preg_match('/\.css/i', $css)) {
							$this->modx->regClientCSS(str_replace('[[+assetsUrl]]', $this->config['assetsUrl'], $css));
						}
					}
					if ($js = trim($this->config['frontend_js'])) {
						if (preg_match('/\.js/i', $js)) {
							$this->modx->regClientScript(str_replace('[[+assetsUrl]]', $this->config['assetsUrl'], $js));
						}
					}
					$config_js = preg_replace(array('/^\n/', '/\t{5}/'), '', '
						msop2 = {};
						msop2Config = {
							jsUrl: "' . $this->config['jsUrl'] . 'web/"
							,webconnector: "' . $this->config['webconnector'] . '"
							,ctx: "' . $this->modx->context->get('key') . '"
						};
					');
					$this->modx->regClientStartupScript("<script type=\"text/javascript\">\n" . $config_js . "\n</script>", true);
				}
				$this->initialized[$ctx] = true;
				break;
		}
		return true;
	}

	/**
	 * @param $sp
	 */
	public function onDocFormPrerender($sp)
	{
		if ($this->modx->getOption('mode', $sp) !== 'upd') {
			return;
		}
		if (!$this->modx->getObject('msProduct', $sp['id'])) {
			return;
		}
		// lexicon
		$this->modx->controller->addLexiconTopic('msop2:default,msop2:manager');
		// css
		$this->modx->regClientCSS($this->getOption('cssUrl') . 'mgr/main.css');
		// js
		$this->modx->regClientStartupScript($this->getOption('jsUrl') . 'mgr/msop2.js');
		$this->modx->regClientStartupScript($this->getOption('jsUrl') . 'mgr/misc/utils.js');
		$this->modx->regClientStartupScript($this->getOption('jsUrl') . 'mgr/misc/msop2.combo.js');
		// remains
		$remains_id = $this->getRemainsOption();
		$weight_id = $this->getWeightOption();
		$article_id = $this->getArticleOption();
		//
		$data_js = preg_replace(array('/^\n/', '/\t{6}/'), '', '
			msop2.config.connector_url = "' . $this->config['connectorUrl'] . '";
			msop2.product_id = ' . $sp['id'] . ';
			msop2.remains_id = ' . $remains_id . ';
			msop2.weight_id = ' . $weight_id . ';
			msop2.article_id = ' . $article_id . ';
		');
		$this->modx->regClientStartupScript("<script type=\"text/javascript\">\n" . $data_js . "\n</script>", true);
		// inject
		$this->modx->regClientStartupScript($this->getOption('jsUrl') . 'mgr/inject/price.grid.js');
		$this->modx->regClientStartupScript($this->getOption('jsUrl') . 'mgr/inject/tab.js');
	}

	/**
	 * @param $sp
	 * @param int $product
	 */
	public function msOnBeforeAddToCart($sp, $product = 0)
	{
		if (empty($sp['options'])) {
			return;
		}
		if (!$id = $product->get('id')) {
			return;
		}
		// set price
		$_price = $this->getPrice($id, $sp['options']);
		$product->set('price', $_price);
		// set weight
		$_weight = $this->getWeight($id, $sp['options']);
		$product->set('weight', $_weight);
	}

	/**
	 * @param $sp
	 */
	public function OnBeforeCacheUpdate($sp)
	{
		// clear cache
		$this->clearCache();
	}

	/**
	 * @param $id
	 * @param array $options
	 * @return int|mixed
	 */
	public function getPrice($id, $options = array())
	{
		if (empty($id)) {
			return 0;
		}
		if (!$product = $this->modx->getObject('msProduct', $id)) {
			return 0;
		}

		$price = $product->get('price');

		$response = $this->invokeEvent('msop2OnBeforeProductGetPrice', array(
			'product' => $product,
			'options' => $options,
			'price' => $price
		));

		if (!$response['success']) {
			return $response['message'];
		}

		$options = $response['data']['options'];
		$price = $response['data']['price'];

		if ($options == '[]') {
			return $price;
		}
		$_prices = array();
		foreach ($options as $k => $v) {
			if (is_array($v)) {
				continue;
			}
			if (!$msop2Option = $this->modx->getObject('msop2Option', array(
				'key' => $k,
				'active' => 1,
			))
			) {
				continue;
			}
			$option = $msop2Option->get('id');
			if (!$msop2Price = $this->modx->getObject('msop2Price', array(
				'product_id' => $id,
				'option' => $option,
				'value' => $v,
				'active' => 1,
			))
			) {
				continue;
			}
			$operation = $msop2Price->get('operation');
			$_price = $msop2Price->get('price');
			//
			if (strpos($_price, '%') !== false) {
				$_price = $price * $_price / 100;
			}
			$_prices[$operation][] = $_price;
		}

		if (!empty($_prices[1])) {
			$price = max($_prices[1]);
			unset($_prices[1]);
		}

		foreach ($_prices as $operation => $v) {
			if (!is_array($v)) {
				continue;
			}
			foreach ($v as $p) {
				if (is_array($p)) {
					continue;
				}
				switch ($operation) {
					case '2': {
						$price += $p;
						break;
					}
					case '3': {
						$price -= $p;
						break;
					}
				}
			}
		}

		if ($price < 0) {
			$price = 0;
		}
		if (($price == 0) && !$this->modx->getOption('msop2_allow_zero_price', null, false)) {
			$price = $product->get('price');
		}

		$response = $this->invokeEvent('msop2OnProductGetPrice', array(
			'product' => $product,
			'options' => $options,
			'price' => $price
		));

		if (!$response['success']) {
			return $response['message'];
		}

		$price = $response['data']['price'];

		return $price;
	}

	/**
	 * @param $id
	 * @param array $options
	 * @return int|mixed
	 */
	public function getWeight($id, $options = array())
	{
		if (empty($id)) {
			return 0;
		}
		if (!$product = $this->modx->getObject('msProduct', $id)) {
			return 0;
		}

		$weight = $product->get('weight');

		$response = $this->invokeEvent('msop2OnBeforeProductGetWeight', array(
			'product' => $product,
			'options' => $options,
			'weight' => $weight
		));

		if (!$response['success']) {
			return $response['message'];
		}

		$options = $response['data']['options'];
		$weight = $response['data']['weight'];

		if ($options == '[]') {
			return $weight;
		}
		$weight_id = $this->getWeightOption();

		if (!empty($weight_id)) {
			foreach ($options as $k => $v) {
				if (is_array($v)) {
					continue;
				}
				if (!$msop2Option = $this->modx->getObject('msop2Option', array(
					'key' => $k,
					'active' => 1,
				))
				) {
					continue;
				}
				$option = $msop2Option->get('id');
				if ($option !== $weight_id) {
					continue;
				}
				if (!$msop2Price = $this->modx->getObject('msop2Price', array(
					'product_id' => $id,
					'option' => $option,
					'value' => $v,
					'active' => 1,
				))
				) {
					continue;
				}
				$weight = $msop2Price->get('weight');
			}
		}

		if (($weight == 0) && !$this->modx->getOption('msop2_allow_zero_weight', null, false)) {
			$weight = $product->get('weight');
		}

		$response = $this->invokeEvent('msop2OnProductGetWeight', array(
			'product' => $product,
			'options' => $options,
			'weight' => $weight
		));

		if (!$response['success']) {
			return $response['message'];
		}

		$weight = $response['data']['weight'];

		return $weight;
	}

	public function getArticle($id, $options = array())
	{
		if (empty($id)) {
			return 0;
		}
		if (!$product = $this->modx->getObject('msProduct', $id)) {
			return '';
		}
		$article = $product->get('article');

		$response = $this->invokeEvent('msop2OnBeforeProductGetArticle', array(
			'product' => $product,
			'options' => $options,
			'article' => $article
		));

		if (!$response['success']) {
			return $response['message'];
		}

		$options = $response['data']['options'];
		$article = $response['data']['article'];

		if ($options == '[]') {
			return $article;
		}
		$article_id = $this->getArticleOption();

		if (!empty($article_id)) {
			foreach ($options as $k => $v) {
				if (is_array($v)) {
					continue;
				}
				if (!$msop2Option = $this->modx->getObject('msop2Option', array(
					'key' => $k,
					'active' => 1,
				))
				) {
					continue;
				}
				$option = $msop2Option->get('id');
				if ($option !== $article_id) {
					continue;
				}
				if (!$msop2Price = $this->modx->getObject('msop2Price', array(
					'product_id' => $id,
					'option' => $option,
					'value' => $v,
					'active' => 1,
				))
				) {
					continue;
				}
				$article = $msop2Price->get('article');
			}
		}

		$response = $this->invokeEvent('msop2OnProductGetArticle', array(
			'product' => $product,
			'options' => $options,
			'article' => $article
		));

		if (!$response['success']) {
			return $response['message'];
		}

		$article = $response['data']['article'];

		return $article;
	}

	/**
	 * @param string $message
	 * @param array $data
	 * @param array $placeholders
	 * @return array|string
	 */
	public function error($message = '', $data = array(), $placeholders = array())
	{
		$response = array(
			'success' => false,
			'message' => $this->modx->lexicon($message, $placeholders),
			'data' => $data,
		);
		return $this->config['json_response']
			? $this->modx->toJSON($response)
			: $response;
	}

	/**
	 * @param string $message
	 * @param array $data
	 * @param array $placeholders
	 * @return array|string
	 */
	public function success($message = '', $data = array(), $placeholders = array())
	{
		$response = array(
			'success' => true,
			'message' => $this->modx->lexicon($message, $placeholders),
			'data' => $data,
		);
		return $this->config['json_response']
			? $this->modx->toJSON($response)
			: $response;
	}

	/**
	 * Function for formatting price
	 * @param string $price
	 *
	 * @return string $price
	 */
	public function formatPrice($price = '0')
	{
		$price = $this->ms2->formatPrice($price);
		return $price;
	}

	/**
	 * Function for formatting weight
	 * @param string $price
	 *
	 * @return string $price
	 */
	public function formatWeight($weight = '0')
	{
		$weight = $this->ms2->formatWeight($weight);
		return $weight;
	}

	/**
	 * @return int
	 */
	public function getRemainsOption()
	{
		$id = 0;
		$q = $this->modx->newQuery('msop2Option');
		$q->sortby('`msop2Option`.`rank`', 'ASC');
		$q->select('`msop2Option`.`id`');
		$q->where(array('msop2Option.active' => 1, 'msop2Option.remains' => 1));
		$q->limit(1);
		if ($q->prepare() && $q->stmt->execute()) {
			$id = $q->stmt->fetch(PDO::FETCH_COLUMN);
		}
		return (int)$id;
	}

	/**
	 * @return int
	 */
	public function getWeightOption()
	{
		$id = 0;
		$q = $this->modx->newQuery('msop2Option');
		$q->sortby('`msop2Option`.`rank`', 'ASC');
		$q->select('`msop2Option`.`id`');
		$q->where(array('msop2Option.active' => 1, 'msop2Option.weight' => 1));
		$q->limit(1);
		if ($q->prepare() && $q->stmt->execute()) {
			$id = $q->stmt->fetch(PDO::FETCH_COLUMN);
		}
		return (int)$id;
	}

	/**
	 * @return int
	 */
	public function getArticleOption()
	{
		$id = 0;
		$q = $this->modx->newQuery('msop2Option');
		$q->sortby('`msop2Option`.`rank`', 'ASC');
		$q->select('`msop2Option`.`id`');
		$q->where(array('msop2Option.active' => 1, 'msop2Option.article' => 1));
		$q->limit(1);
		if ($q->prepare() && $q->stmt->execute()) {
			$id = $q->stmt->fetch(PDO::FETCH_COLUMN);
		}
		return (int)$id;
	}

//

	/**
	 * @param $data
	 * @return int
	 */
	public function getRemainsCount($data)
	{
		$count = 0;
		$q = $this->modx->newQuery('msop2Price');
		$data['active'] = 1;
		$q->where($data);
		foreach ($this->modx->getIterator('msop2Price', $q) as $_price) {
			$count = $_price->get('count');
		}
		return $count;
	}

	/**
	 * @param $key
	 * @param array $data
	 * @param int $lifetime
	 * @param array $options
	 *
	 * @return string
	 */
	public function setCache($key, $data = array(), $lifetime = 0, $options = array())
	{
		$cacheKey = $this->config['cache_key'];
		if (array_key_exists('path', $options)) {
			$cacheKey .= $options['path'] . '/';
		}
		if (array_key_exists('hash', $options)) {
			$key = sha1(serialize($options + array($key)));
		}
		$cacheOptions = array(xPDO::OPT_CACHE_KEY => $cacheKey);
		if (!empty($key) && !empty($cacheOptions) && $this->modx->getCacheManager()) {
			$this->modx->cacheManager->set(
				$key,
				$data,
				(integer)$lifetime,
				$cacheOptions
			);
		}

		return $key;
	}

	/**
	 * @param $key
	 * @param array $options
	 *
	 * @return mixed|string
	 */
	public function getCache($key, $options = array())
	{
		$cacheKey = $this->config['cache_key'];
		if (array_key_exists('path', $options)) {
			$cacheKey .= $options['path'] . '/';
		}
		if (array_key_exists('hash', $options)) {
			$key = sha1(serialize($options + array($key)));
		}
		$cacheOptions = array(xPDO::OPT_CACHE_KEY => $cacheKey);
		$cached = '';
		if (!empty($key) && !empty($cacheOptions) && $this->modx->getCacheManager()) {
			$cached = $this->modx->cacheManager->get($key, $cacheOptions);
		}

		return $cached;
	}

	/**
	 * @param $key
	 * @return mixed
	 */
	public function clearCache()
	{
		$cacheKey = $this->config['cache_key'];
		$cacheOptions = array(xPDO::OPT_CACHE_KEY => $cacheKey);
		if (!empty($cacheOptions) && $this->modx->getCacheManager()) {
			$this->modx->cacheManager->clean($cacheOptions);
		}

		return true;
	}

	/**
	 * from https://github.com/bezumkin/miniShop2/blob/master/core/components/minishop2/model/minishop2/minishop2.class.php#L595
	 *
	 * Shorthand for original modX::invokeEvent() method with some useful additions.
	 *
	 * @param $eventName
	 * @param array $params
	 * @param $glue
	 *
	 * @return array
	 */
	public function invokeEvent($eventName, array $params = array(), $glue = '<br/>')
	{
		if (isset($this->modx->event->returnedValues)) {
			$this->modx->event->returnedValues = null;
		}
		$response = $this->modx->invokeEvent($eventName, $params);
		if (is_array($response) && count($response) > 1) {
			foreach ($response as $k => $v) {
				if (empty($v)) {
					unset($response[$k]);
				}
			}
		}
		$message = is_array($response) ? implode($glue, $response) : trim((string)$response);
		if (isset($this->modx->event->returnedValues) && is_array($this->modx->event->returnedValues)) {
			$params = array_merge($params, $this->modx->event->returnedValues);
		}
		return array(
			'success' => empty($message),
			'message' => $message,
			'data' => $params
		);
	}


}