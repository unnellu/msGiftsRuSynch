<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'msop2Price',
    1 => 'msop2Option',
    2 => 'msop2Operation',
  ),
);