<?php

/**
 * Manager Russian Lexicon Entries for msOptionsPrice
 *
 * @package msop2
 * @subpackage lexicon
 */

// buttons
$_lang['msop2_btn_create'] = 'Создать';
$_lang['msop2_btn_save'] = 'Сохранить';
$_lang['msop2_btn_edit'] = 'Изменить';
$_lang['msop2_btn_view'] = 'Просмотр';
$_lang['msop2_btn_delete'] = 'Удалить';
$_lang['msop2_btn_delete_all'] = 'Удалить все';
$_lang['msop2_btn_undelete'] = 'Восстановить';
$_lang['msop2_btn_publish'] = 'Включить';
$_lang['msop2_btn_unpublish'] = 'Отключить';
$_lang['msop2_btn_cancel'] = 'Отмена';
$_lang['msop2_btn_duplicate'] = 'Сделать копию';
$_lang['msop2_btn_update'] = 'Обновить';


$_lang['msop2_sections'] = 'Раздел';
$_lang['msop2_search_by_key'] = 'Искать';
$_lang['msop2_rewrite'] = 'Перезаписать';
$_lang['msop2_bulk_actions'] = 'Действия';
$_lang['msop2_active'] = 'Включен';
$_lang['msop2_name'] = 'Имя';
$_lang['msop2_key'] = 'Свойство';
$_lang['msop2_description'] = 'Описание';
$_lang['msop2_num'] = 'Номер';
$_lang['msop2_status'] = 'Статус';
$_lang['msop2_count'] = 'Количество';
$_lang['msop2_id'] = 'Id';
$_lang['msop2_type'] = 'Тип';
$_lang['msop2_type_change'] = 'Тип изменения';
$_lang['msop2_user_id'] = 'Id пользователя';
$_lang['msop2_customer'] = 'Пользователь';
$_lang['msop2_field'] = 'Поле';
$_lang['msop2_createdon'] = 'Создан';
$_lang['msop2_updatedon'] = 'Обновлен';
$_lang['msop2_comment'] = 'Комментарий';
$_lang['msop2_operation'] = 'Операция';
$_lang['msop2_products'] = 'Продукты';
$_lang['msop2_all'] = 'Все';
$_lang['msop2_empty'] = 'Нет';
$_lang['msop2_empty_select'] = 'Не выбран';
$_lang['msop2_level'] = 'Уровень';
$_lang['msop2_filter_select'] = 'Выберите фильтр ';
$_lang['msop2_category'] = 'Категория';
$_lang['msop2_template'] = 'Шаблон';
$_lang['msop2_is_active'] = 'Активный';
$_lang['msop2_not_active'] = 'Неактивный';
$_lang['msop2_value'] = 'Значение';
$_lang['msop2_percent'] = 'Процент';
$_lang['msop2_round'] = 'Округлить до ';
$_lang['msop2_price'] = 'Цена';
$_lang['msop2_option'] = 'Опция';
$_lang['msop2_color'] = 'Цвет';
$_lang['msop2_remains'] = 'Остаток';
$_lang['msop2_weight'] = 'Вес';
$_lang['msop2_pieces'] = ' шт.<br>';
$_lang['msop2_article'] = 'Артикул';


// menu
$_lang['msop2_menu_create'] = 'Создать';
$_lang['msop2_menu_add'] = 'Добавить';
$_lang['msop2_menu_set'] = 'Установить';
$_lang['msop2_menu_update'] = 'Изменить';
$_lang['msop2_menu_remove'] = 'Удалить';
$_lang['msop2_menu_active'] = 'Активировать';
$_lang['msop2_menu_inactive'] = 'Деактивировать';
$_lang['msop2_menu_cancel'] = 'Отменить';
$_lang['msop2_menu_change'] = 'Изменить';
$_lang['msop2_menu_cancel_operation'] = 'Отменить операцию';
$_lang['msop2_menu_remove_multiple'] = 'Удалить выбранное';
$_lang['msop2_menu_remove_all'] = 'Удалить все';

$_lang['msop2_price_selected_delete'] = 'Удалить все';
$_lang['msop2_price_selected_set_value'] = 'Установить цену';
$_lang['msop2_price_selected_set_active'] = 'Активировать';
$_lang['msop2_price_selected_set_inactive'] = 'Деактивировать';
$_lang['msop2_price_create_all'] = 'Создать все';


// confirm
$_lang['msop2_menu_cancel_confirm'] = 'Вы уверены, что хотите отменить эту запись?';
$_lang['msop2_menu_remove_confirm'] = 'Вы уверены, что хотите удалить эту запись?';
$_lang['msop2_menu_remove_all_confirm'] = 'Вы уверены, что хотите удалить все записи?';
$_lang['msop2_menu_cancel_operation_confirm'] = 'Вы уверены, что хотите отменить эту операцию?';
$_lang['msop2_menu_remove_multiple_confirm'] = 'Вы уверены, что хотите удалить все выбранные записи?';
$_lang['msop2_menu_active_multiple_confirm'] = 'Вы уверены, что хотите активировать все выбранные записи?';
$_lang['msop2_menu_inactive_multiple_confirm'] = 'Вы уверены, что хотите деактивировать все выбранные записи?';

// error
$_lang['msop2_err_non_key_unique'] = 'Такое свойство уже есть!';
$_lang['msop2_err_non_name_unique'] = 'Такое имя уже есть!';
$_lang['msop2_err_non_unique'] = 'Такое значение уже есть!';

// tab
$_lang['msop2_tab_title'] = 'Опции - цены';
$_lang['msop2_tab_intro'] = 'Опции - цены';

//
$_lang['msop2_available_count'] = 'Количество доступное к заказу: ';
$_lang['msop2_available_count_no'] = 'Нет доступного кол-ва для заказа. ';
