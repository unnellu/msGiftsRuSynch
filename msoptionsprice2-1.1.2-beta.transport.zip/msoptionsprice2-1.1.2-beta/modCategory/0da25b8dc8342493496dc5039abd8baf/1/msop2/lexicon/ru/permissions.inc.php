<?php

$_lang['msop2setting_list'] = 'Разрешает вывод';
$_lang['msop2setting_save'] = 'Разрешает создание\изменение';
$_lang['msop2setting_view'] = 'Разрешает просмотр';