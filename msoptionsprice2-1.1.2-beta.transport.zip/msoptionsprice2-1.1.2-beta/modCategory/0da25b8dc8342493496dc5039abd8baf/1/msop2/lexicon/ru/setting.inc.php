<?php

$_lang['area_msop2_main'] = 'Основные';

$_lang['setting_msop2_active'] = 'Включить / Выключить';
$_lang['setting_msop2_active_desc'] = 'Включить / Выключить дополнительные цены Minishop2.';

$_lang['setting_msop2_allow_zero_price'] = 'Разрешить нулевую стоимость';
$_lang['setting_msop2_allow_zero_price_desc'] = 'В результате подсчета стоимость может быть нулевая. Данная опция разрешает такие цены.';

$_lang['setting_msop2_allow_zero_weight'] = 'Разрешить нулевой вес';
$_lang['setting_msop2_allow_zero_weight_desc'] = 'Данная опция разрешает нулевой вес товара. При выключенной настройке будет взят действительный вес товара.';

$_lang['setting_msop2_frontend_js'] = 'Файл с javascript';
$_lang['setting_msop2_frontend_js_desc'] = 'Файл с javascript для подключения на фронтенде. ';

$_lang['setting_msop2_frontend_css'] = 'Файл с css';
$_lang['setting_msop2_frontend_css_desc'] = 'Файл с css для подключения на фронтенде. ';

$_lang['setting_msop2_show_count'] = 'Показывать количество';
$_lang['setting_msop2_show_count_desc'] = 'При включенной настройке, на странице товара, будет отображена колонка - "Количество" товара. ';

$_lang['setting_msop2_show_weight'] = 'Показывать вес';
$_lang['setting_msop2_show_weight_desc'] = 'При включенной настройке, на странице товара, будет отображена колонка - "Вес" товара. ';

$_lang['setting_msop2_show_article'] = 'Показывать артикул';
$_lang['setting_msop2_show_article_desc'] = 'При включенной настройке, на странице товара, будет отображена колонка - "Артикул" товара. ';
