<?php

/**
 * Manager English Lexicon Entries for msOptionPrice
 *
 * @package msop2
 * @subpackage lexicon
 */

// buttons
$_lang['msop2_btn_create'] = 'Create';
$_lang['msop2_btn_save'] = 'Save';
$_lang['msop2_btn_edit'] = 'Change';
$_lang['msop2_btn_view'] = 'View';
$_lang['msop2_btn_delete'] = 'Remove';
$_lang['msop2_btn_delete_all'] = 'Remove all';
$_lang['msop2_btn_undelete'] = 'Restore';
$_lang['msop2_btn_publish'] = 'Enable';
$_lang['msop2_btn_unpublish'] = 'Disable';
$_lang['msop2_btn_cancel'] = 'Cancel';
$_lang['msop2_btn_duplicate'] = 'Make a copy';
$_lang['msop2_btn_update'] = 'Update';

//
$_lang['msop2_sections'] = 'Sections';
$_lang['msop2_search_by_key'] = 'Search';
$_lang['msop2_rewrite'] = 'Overwrite';
$_lang['msop2_bulk_actions'] = 'Action';
$_lang['msop2_active'] = 'Active';
$_lang['msop2_name'] = 'Name';
$_lang['msop2_key'] = 'Key';
$_lang['msop2_description'] = 'Description';
$_lang['msop2_num'] = 'Num';
$_lang['msop2_status'] = 'Status';
$_lang['msop2_count'] = 'Count';
$_lang['msop2_id'] = 'Id';
$_lang['msop2_type'] = 'Type';
$_lang['msop2_type_change'] = 'Type change';
$_lang['msop2_user_id'] = 'User id';
$_lang['msop2_customer'] = 'User';
$_lang['msop2_field'] = 'Field';
$_lang['msop2_createdon'] = 'Createdon';
$_lang['msop2_updatedon'] = 'Updatedon';
$_lang['msop2_comment'] = 'Comment';
$_lang['msop2_operation'] = 'Operation';
$_lang['msop2_products'] = 'Products';
$_lang['msop2_all'] = 'All';
$_lang['msop2_empty'] = 'Not';
$_lang['msop2_empty_select'] = 'Not selected';
$_lang['msop2_level'] = 'Level';
$_lang['msop2_filter_select'] = 'Select filter';
$_lang['msop2_category'] = 'Category';
$_lang['msop2_template'] = 'Template';
$_lang['msop2_is_active'] = 'Active';
$_lang['msop2_not_active'] = 'Not active';
$_lang['msop2_value'] = 'Value';
$_lang['msop2_product_old_value'] = 'Old value of the product';
$_lang['msop2_product_value'] = 'Value of the product';
$_lang['msop2_percent'] = 'Percent';
$_lang['msop2_round'] = 'Round to ';
$_lang['msop2_price'] = 'Price';
$_lang['msop2_option'] = 'Option';
$_lang['msop2_color'] = 'Color';
$_lang['msop2_weight'] = 'Weight';
$_lang['msop2_remains'] = 'Remains';
$_lang['msop2_article'] = 'Article';


// menu
$_lang['msop2_menu_create'] = 'Create';
$_lang['msop2_menu_add'] = 'Add';
$_lang['msop2_menu_set'] = 'Set';
$_lang['msop2_menu_update'] = 'Change';
$_lang['msop2_menu_remove'] = 'Remove';
$_lang['msop2_menu_active'] = 'Set active';
$_lang['msop2_menu_inactive'] = 'Set inactive';
$_lang['msop2_menu_cancel'] = 'Cancel';
$_lang['msop2_menu_change'] = 'Change';
$_lang['msop2_menu_cancel_operation'] = 'Cancel operation';
$_lang['msop2_menu_remove_multiple'] = 'Remove multiple';
$_lang['msop2_menu_remove_all'] = 'Remove all';

$_lang['msop2_price_selected_delete'] = 'Delete all';
$_lang['msop2_price_selected_set_value'] = 'Set value';
$_lang['msop2_price_selected_set_active'] = 'Set active';
$_lang['msop2_price_selected_set_inactive'] = 'Set inactive';
$_lang['msop2_price_create_all'] = 'Create all';

// confirm
$_lang['msop2_menu_cancel_confirm'] = 'Are you sure you want to cancel this record?';
$_lang['msop2_menu_remove_confirm'] = 'Are you sure you want to delete this record?';
$_lang['msop2_menu_remove_all_confirm'] = 'Are you sure you want to delete all records?';
$_lang['msop2_menu_cancel_operation_confirm'] = 'Are you sure you want to cancel this operation?';
$_lang['msop2_menu_remove_multiple_confirm'] = 'Are you sure you want to delete all selected records?';
$_lang['msop2_menu_active_multiple_confirm'] = 'Are you sure you want to activate all selected records?';
$_lang['msop2_menu_inactive_multiple_confirm'] = 'Are you sure you want to inactivate all selected records?';

// error
$_lang['msop2_err_non_key_unique'] = 'This property already has!';
$_lang['msop2_err_non_name_unique'] = 'This name already has!';
$_lang['msop2_err_non_unique'] = 'This value already has!';

// tab
$_lang['msop2_tab_title'] = 'Options - price';
$_lang['msop2_tab_intro'] = 'Options - price';