<?php
include_once 'setting.inc.php';

$_lang['msop2'] = 'msOptionsPrice2';
$_lang['msop2_menu_desc'] = 'Дополнительные цены - настройки.';

$_lang['msop2_settings'] = 'Настройки';

$_lang['msop2_setting_option'] = 'Опции';
$_lang['msop2_setting_option_intro'] = 'Панель управления опциями продукта.';

$_lang['msop2_setting_operation'] = 'Операции';
$_lang['msop2_setting_operation_intro'] = 'Панель управления операциями над ценами.';