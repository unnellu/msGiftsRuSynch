<?php

$_lang['msop2setting_list'] = 'Allows conclusion';
$_lang['msop2setting_save'] = 'Allows creating \ change';
$_lang['msop2setting_view'] = 'Allows viewing';