<?php

$_lang['area_msop2_main'] = 'Main';

$_lang['setting_msop2_active'] = 'Active / Inactive';

$_lang['setting_msop2_allow_zero_price'] = 'Allow zero price';

$_lang['setting_msop2_frontend_js'] = 'Frontend javascript';

$_lang['setting_msop2_frontend_css'] = 'Frontend css';
