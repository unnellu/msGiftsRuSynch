--------------------
msOptionsPrice2
--------------------
Author: Vgrish <vgrish@gmail.com>
--------------------

A basic Extra for MODx Revolution.