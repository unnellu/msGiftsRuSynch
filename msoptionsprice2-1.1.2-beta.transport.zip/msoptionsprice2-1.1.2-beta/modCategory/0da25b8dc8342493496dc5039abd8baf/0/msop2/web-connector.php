<?php
//
if (!empty($_REQUEST['action'])) {
	@session_cache_limiter('nocache');
	define('MODX_REQP', false);
}
// Load MODX config
if (file_exists(dirname(dirname(dirname(dirname(__FILE__)))) . '/config.core.php')) {
	require_once dirname(dirname(dirname(dirname(__FILE__)))) . '/config.core.php';
} else {
	require_once dirname(dirname(dirname(dirname(dirname(__FILE__))))) . '/config.core.php';
}
require_once MODX_CORE_PATH . 'config/' . MODX_CONFIG_KEY . '.inc.php';
require_once MODX_CONNECTORS_PATH . 'index.php';
//
if ($modx->user->hasSessionContext($modx->context->get('key'))) {
	$_SERVER['HTTP_MODAUTH'] = $_SESSION["modx." . $modx->context->get('key') . ".user.token"];
} else {
	$_SESSION["modx." . $modx->context->get('key') . ".user.token"] = 0;
	$_SERVER['HTTP_MODAUTH'] = 0;
}
require_once MODX_CORE_PATH . 'config/' . MODX_CONFIG_KEY . '.inc.php';
require_once MODX_CONNECTORS_PATH . 'index.php';
//
$corePath = $modx->getOption('msop2_core_path', null, $modx->getOption('core_path') . 'components/msop2/');
$msop2 = $modx->getService('msop2', 'msop2', $corePath . 'model/msop2/');
$modx->lexicon->load('msop2:default', 'msop2:manager');
// handle request
$path = $modx->getOption('processorsPath', $msop2->config, $corePath . 'processors/');
$modx->request->handleRequest(array(
	'processors_path' => $path . 'web/',
	'location' => '',
));