msop2.page.Settings = function(config) {
    config = config || {};
    Ext.applyIf(config, {
        components: [{
            xtype: 'msop2-panel-settings',
            renderTo: 'msop2-panel-settings-div'
        }]
    });
    msop2.page.Settings.superclass.constructor.call(this, config);
};
Ext.extend(msop2.page.Settings, MODx.Component);
Ext.reg('msop2-page-settings', msop2.page.Settings);

msop2.panel.Settings = function(config) {
    config = config || {};
    Ext.apply(config, {
        border: false,
        deferredRender: true,
        baseCls: 'modx-formpanel',
        items: [{
            html: '<h2>' + _('msop2') + ' :: ' + _('msop2_settings') + '</h2>',
            border: false,
            cls: 'modx-page-header container'
        }, {
            xtype: 'modx-tabs',
            id: 'msop2-settings-tabs',
            bodyStyle: 'padding: 10px',
            defaults: {
                border: false,
                autoHeight: true
            },
            border: true,
            hideMode: 'offsets'

            ,
            items: [{
                title: _('msop2_setting_option'),
                items: [{
                    html: '<p>' + _('msop2_setting_option_intro') + '</p>',
                    border: false,
                    bodyCssClass: 'panel-desc',
                    bodyStyle: 'margin-bottom: 10px'
                }, {
                    xtype: 'msop2-grid-setting-option'
                }]
            }, {
                title: _('msop2_setting_operation'),
                items: [{
                    html: '<p>' + _('msop2_setting_operation_intro') + '</p>',
                    border: false,
                    bodyCssClass: 'panel-desc',
                    bodyStyle: 'margin-bottom: 10px'
                }, {
                    xtype: 'msop2-grid-setting-operation'
                }]
            }, {
                title: _('msop2_lexicon_editor'),
                items: [{
                    html: '<p>' + _('msop2_lexicon_editor_intro') + '</p>',
                    border: false,
                    bodyCssClass: 'panel-desc',
                    bodyStyle: 'margin-bottom: 10px'
                }, {
                    // xtype: 'msop2-grid-lexicon'
                }]
            }]

        }]
    });
    msop2.panel.Settings.superclass.constructor.call(this, config);
};
Ext.extend(msop2.panel.Settings, MODx.Panel);
Ext.reg('msop2-panel-settings', msop2.panel.Settings);
