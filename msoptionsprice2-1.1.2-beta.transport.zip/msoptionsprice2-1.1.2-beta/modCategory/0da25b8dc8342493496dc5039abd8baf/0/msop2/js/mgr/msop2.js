var msop2 = function(config) {
	config = config || {};
	msop2.superclass.constructor.call(this, config);
};
Ext.extend(msop2, Ext.Component, {
	page: {},
	window: {},
	grid: {},
	tree: {},
	panel: {},
	combo: {},
	config: {},
	view: {},
	utils: {},
	keymap: {},
	plugin: {}
});
Ext.reg('msop2', msop2);

msop2 = new msop2();
