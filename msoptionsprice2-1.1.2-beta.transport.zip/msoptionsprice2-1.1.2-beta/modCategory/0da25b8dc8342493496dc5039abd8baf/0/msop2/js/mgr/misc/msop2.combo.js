Ext.namespace('msop2.combo');

msop2.combo.ProductKey = function(config) {
    config = config || {};

    Ext.applyIf(config, {
        name: 'property',
        id: 'msop2-combo-product-key',
        hiddenName: 'key',
        displayField: 'name',
        valueField: 'id',
        editable: true,
        fields: ['id', 'name'],
        pageSize: 10,
        emptyText: _('msop2_combo_select'),
        hideMode: 'offsets',
        url: msop2.config.connector_url,
        baseParams: {
            action: 'mgr/misc/product/key/getlist'
        }
    });
    msop2.combo.ProductKey.superclass.constructor.call(this, config);
};
Ext.extend(msop2.combo.ProductKey, MODx.combo.ComboBox);
Ext.reg('msop2-combo-product-key', msop2.combo.ProductKey);


msop2.combo.Option = function(config) {
    config = config || {};

    Ext.applyIf(config, {
        name: 'option',
        id: 'msop2-combo-option',
        hiddenName: 'option',
        displayField: 'name',
        valueField: 'id',
        valueHiddenField: 'key',
        editable: true,
        fields: ['id', 'name', 'description', 'key'],
        pageSize: 10,
        emptyText: _('msop2_filter_select'),
        hideMode: 'offsets',
        url: msop2.config.connector_url,
        baseParams: {
            action: 'mgr/misc/option/getlist',
            addall: config.addall || 0
        },
        tpl: new Ext.XTemplate('' + '<tpl for="."><div class="x-combo-list-item msop2-option-list-item">' + '<span><b>{name}</b></span>' + '<small> [{key}] </small>' + '<tpl if="description">' + '<span class="description">' + '<nobr><small>{description}</small></nobr>' + '</span>' + '</tpl>'

        + '</div></tpl>', {
            compiled: true
        }),
        itemSelector: 'div.msop2-option-list-item'
    });

    msop2.combo.Option.superclass.constructor.call(this, config);
};
Ext.extend(msop2.combo.Option, MODx.combo.ComboBox);
Ext.reg('msop2-combo-option', msop2.combo.Option);


msop2.combo.Operation = function(config) {
    config = config || {};

    Ext.applyIf(config, {
        name: 'option',
        id: 'msop2-combo-operation',
        hiddenName: 'option',
        displayField: 'name',
        valueField: 'id',
        editable: true,
        fields: ['id', 'name', 'description'],
        pageSize: 10,
        emptyText: _('msop2_combo_select'),
        hideMode: 'offsets',
        url: msop2.config.connector_url,
        baseParams: {
            action: 'mgr/misc/operation/getlist'
        },
        tpl: new Ext.XTemplate('' + '<tpl for="."><div class="x-combo-list-item msop2-operation-list-item">' + '<span><b>{name}</b></span>' + '<tpl if="description">' + '<span class="description">' + '<nobr><small>{description}</small></nobr>' + '</span>' + '</tpl>'

        + '</div></tpl>', {
            compiled: true
        }),
        itemSelector: 'div.msop2-operation-list-item'
    });
    msop2.combo.Operation.superclass.constructor.call(this, config);
};
Ext.extend(msop2.combo.Operation, MODx.combo.ComboBox);
Ext.reg('msop2-combo-operation', msop2.combo.Operation);


msop2.combo.minishop2OneOptions = function(config) {
    config = config || {};
    Ext.applyIf(config, {
        xtype: 'superboxselect'

        ,
        allowBlank: false,
        allowAddNewData: false,
        addNewDataOnBlur: false,
        forceSameValueQuery: true,
        editable: false

        ,
        msgTarget: 'under',
        resizable: true,
        forceFormValue: false

        ,
        name: config.name || 'tags',
        anchor: '100%',
        minChars: 2,
        pageSize: 10

        ,
        store: new Ext.data.JsonStore({
            id: (config.name || 'tags') + '-msbe-minishop2-options',
            root: 'results',
            autoLoad: true,
            autoSave: false,
            totalProperty: 'total',
            fields: ['value'],
            url: msop2.config.connector_url,
            baseParams: {
                action: 'mgr/misc/product/options/getoptions',
                option_id: config.option_id,
                product_id: config.product_id,
                //limit: 2
            }
        }),
        mode: 'remote',
        displayField: 'value',
        valueField: 'value',
        triggerAction: 'all',
        extraItemCls: 'x-tag',
        originalName: config.name,
        expandBtnCls: MODx.modx23 ? 'x-form-trigger' : 'x-superboxselect-btn-expand',
        clearBtnCls: MODx.modx23 ? 'x-form-trigger' : 'x-superboxselect-btn-clear',
        listeners: {
            beforeadditem: function() {
                this.removeAllItems();
            }
        }
    });
    msop2.combo.minishop2OneOptions.superclass.constructor.call(this, config);
};
Ext.extend(msop2.combo.minishop2OneOptions, Ext.ux.form.SuperBoxSelect);
Ext.reg('msop2-minishop2-combo-one-options', msop2.combo.minishop2OneOptions);
