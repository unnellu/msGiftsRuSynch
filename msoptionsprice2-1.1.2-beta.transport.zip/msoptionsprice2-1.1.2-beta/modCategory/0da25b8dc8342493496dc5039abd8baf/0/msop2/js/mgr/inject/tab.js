Ext.ComponentMgr.onAvailable('minishop2-product-settings-panel', function() {
    this.on('beforerender', function() {

        this.add({
            title: _('msop2_tab_title'),
            hideMode: 'offsets',
            items: [
                /* {
                 html: _('msop2_tab_intro'),
                 cls: 'modx-page-header container',
                 border: false
                 },*/
                {
                    xtype: 'msop2-product-prices-grid'
                }
            ]
        });
    });
});