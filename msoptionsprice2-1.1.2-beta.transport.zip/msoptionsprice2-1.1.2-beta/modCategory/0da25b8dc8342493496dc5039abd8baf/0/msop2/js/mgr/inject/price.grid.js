msop2.grid.Price = function(config) {
    config = config || {};
    config.product_id = msop2.product_id;

    this.sm = new Ext.grid.CheckboxSelectionModel();

    if (!config.menu) {
        config.menu = [];
    }

    config.menu.push({
        text: _('msop2_price_create_all'),
        handler: this.createAll,
        scope: this
    });
    config.menu.push({
        text: _('msop2_price_selected_set_value'),
        handler: this.setValueSelected,
        scope: this
    });
    config.menu.push('-');
    config.menu.push({
        text: _('msop2_price_selected_set_active'),
        handler: this.activeSelected,
        scope: this
    }, {
        text: _('msop2_price_selected_set_inactive'),
        handler: this.inactiveSelected,
        scope: this
    });
    config.menu.push('-');
    config.menu.push({
        text: _('msop2_price_selected_delete'),
        handler: this.deleteSelected,
        scope: this
    });


    if (!config.tbar) {
        config.tbar = [];
    }
    config.tbar.push({
        text: '<i class="icon icon-list"></i> ' + _('msop2_bulk_actions'),
        menu: config.menu
    }, '-', {
        text: '<i class="icon icon-plus"></i> ' + _('msop2_btn_create'),
        handler: this.createPrice,
        scope: this
    }, '->', {
        xtype: 'msop2-combo-option',
        id: 'msbatcheditor-combo-active-selection',
        name: 'active',
        queryParam: 'active',
        addall: 1,
        width: 160,
        listeners: {
            select: {
                fn: this.setOptionFilter,
                scope: this
            }
        }
    });


    Ext.applyIf(config, {
        id: 'msop2-grid-product-price',
        url: msop2.config.connector_url,
        baseParams: {
            action: 'mgr/price/getlist',
            product_id: config.product_id
        },
        fields: ['id', 'product_id', 'option', 'value', 'price', 'count', 'weight', 'article', 'operation', 'rank', 'active', 'option_name', 'operation_name'],
        columns: this.getColumns(),
        paging: true,
        autoHeight: true,
        remoteSort: true,
        sm: this.sm,
        save_action: 'mgr/price/updatefromgrid',
        autosave: true,
        save_callback: this.updateRow

    });
    msop2.grid.Price.superclass.constructor.call(this, config);
};
Ext.extend(msop2.grid.Price, MODx.grid.Grid, {

    getMenu: function() {
        var m = [];
        m.push({
            text: _('msop2_menu_remove'),
            handler: this.removePrice
        });
        m.push({
            text: _('msop2_menu_update'),
            handler: this.updatePrice
        });
        this.addContextMenuItem(m);
    },

    getColumns: function() {
        var columns = [this.sm];

        columns.push({
            header: _('msop2_id'),
            dataIndex: 'id',
            width: 25,
            sortable: true
        }, {
            header: _('msop2_option'),
            dataIndex: 'option_name',
            width: 75,
            sortable: true
        }, {
            header: _('msop2_value'),
            dataIndex: 'value',
            width: 75,
            sortable: true
        }, {
            header: _('msop2_operation'),
            dataIndex: 'operation_name',
            width: 75,
            sortable: true
        }, {
            header: _('msop2_price'),
            dataIndex: 'price',
            width: 75,
            sortable: true,
            editor: {
                xtype: 'textfield'
            }
        });

        if (MODx.config.msop2_show_count != 0) {
            columns.push({
                header: _('msop2_count'),
                dataIndex: 'count',
                width: 75,
                sortable: true,
                editor: {
                    xtype: 'numberfield'
                },
                renderer: msop2.utils.renderCount
            });
        }
        if (MODx.config.msop2_show_weight != 0) {
            columns.push({
                header: _('msop2_weight'),
                dataIndex: 'weight',
                width: 75,
                sortable: true,
                editor: {
                    xtype: 'numberfield'
                },
                renderer: msop2.utils.renderWeight
            });
        }
        if (MODx.config.msop2_show_article != 0) {
            columns.push({
                header: _('msop2_article'),
                dataIndex: 'article',
                width: 75,
                sortable: true,
                editor: {
                    xtype: 'textfield'
                },
                renderer: msop2.utils.renderArticle
            });
        }
        columns.push({
            header: _('msop2_active'),
            dataIndex: 'active',
            sortable: true,
            width: 50,
            editor: {
                xtype: 'combo-boolean',
                renderer: 'boolean'
            }
        });

        return columns;
    },

    setOptionFilter: function(cb) {
        this.getStore().baseParams['option'] = cb.value;
        this.getBottomToolbar().changePage(1);
        //this.refresh();
    },

    updateRow: function(response) {
        var row = response.object;
        var items = this.store.data.items;

        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            if (item.id == row.id) {
                item.data = row;
            }
        }
    },

    createPrice: function(btn, e) {

        var product_id = btn.scope.config.product_id;

        if (this.windows.createPrice) {
            try {
                this.windows.createPrice.close();
                this.windows.createPrice.destroy();
                this.windows.createPrice = undefined;
            } catch (e) {}
        }

        if (!this.windows.createPrice) {
            this.windows.createPrice = MODx.load({
                xtype: 'msop2-window-price-create',
                title: _('msop2_btn_create'),
                fields: this.getPriceFields('create'),
                baseParams: {
                    action: 'mgr/price/create'
                },
                listeners: {
                    success: {
                        fn: function() {
                            this.refresh();
                        },
                        scope: this
                    }
                }
            });
        }
        this.windows.createPrice.fp.getForm().reset();
        this.windows.createPrice.fp.getForm().setValues({
            product_id: product_id,
            operation: 1,
            active: 1,
            count: 0
        });
        this.windows.createPrice.show(e.target);
    },

    updatePrice: function(btn, e, row) {
        if (typeof(row) != 'undefined') {
            this.menu.record = row.data;
        }
        var id = this.menu.record.id;
        var product_id = btn.scope.config.product_id;

        MODx.Ajax.request({
            url: msop2.config.connector_url,
            params: {
                action: 'mgr/price/get',
                id: id
            },
            listeners: {
                success: {
                    fn: function(r) {

                        if (this.windows.updatePrice) {
                            try {
                                this.windows.updatePrice.close();
                                this.windows.updatePrice.destroy();
                            } catch (e) {}
                        }
                        this.windows.updatePrice = MODx.load({
                            xtype: 'msop2-window-price-update',
                            record: r.object,
                            fields: this.getPriceFields('update'),
                            listeners: {
                                success: {
                                    fn: function() {
                                        this.refresh();
                                    },
                                    scope: this
                                }
                            }
                        });
                        this.windows.updatePrice.fp.getForm().reset();
                        this.windows.updatePrice.fp.getForm().setValues(r.object);
                        this.windows.updatePrice.show(e.target);
                    },
                    scope: this
                }
            }
        });
    },

    handleChangeOperation: function(type) {
        var el = Ext.getCmp('msop2-product-operation-handle-' + type);
        var price = Ext.getCmp('msop2-product-price-text-' + type);

        switch (el.value) {
            case 1:
            case '1':
            {
                price.maskRe = /[0123456789\.\-]/;

                break;
            }
            case 2:
            case 3:
            case '2':
            case '3':
            {
                price.maskRe = /[0123456789\.\-%]/;

                break;
            }
        }
    },

    handleChangeOption: function(type) {
        var el = Ext.getCmp('msop2-product-option-' + type);
        var option = Ext.getCmp('msop2-minishop2-combo-one-options-' + type);
        option.store.baseParams.option_id = el.value;
        option.removeAllItems();
        option.enable();
        option.enable();

        /*--- count ---*/
        var count = Ext.getCmp('msop2-product-price-count-' + type);
        if (count) {
            if (el.value == msop2.remains_id) {
                count.enable().show();
            } else {
                count.disable().hide();
            }
        }

        /*--- weight ---*/
        var weight = Ext.getCmp('msop2-product-price-weight-' + type);
        if (weight) {
            if (el.value == msop2.weight_id) {
                weight.enable().show();
            } else {
                weight.disable().hide();
            }
        }

        /*--- article ---*/
        var article = Ext.getCmp('msop2-product-price-article-' + type);
        if (article) {
            if (el.value == msop2.article_id) {
                article.enable().show();
            } else {
                article.disable().hide();
            }
        }
    },

    handleHideOption: function(type) {
        var el = Ext.getCmp('msop2-product-option-' + type);
        var option = Ext.getCmp('msop2-minishop2-combo-one-options-' + type);
        if (option) {
            option.disable();
        }

        /*--- count ---*/
        var count = Ext.getCmp('msop2-product-price-count-' + type);
        if (count) {
            if ((type == 'create') || ((type == 'update') && (el.value !== msop2.remains_id))) {
                count.disable().hide();
            }
        }
        /*--- weight ---*/
        var weight = Ext.getCmp('msop2-product-price-weight-' + type);
        if (weight) {
            if ((type == 'create') || ((type == 'update') && (el.value !== msop2.weight_id))) {
                weight.disable().hide();
            }
        }
        /*--- article ---*/
        var article = Ext.getCmp('msop2-product-price-article-' + type);
        if (article) {
            if ((type == 'create') || ((type == 'update') && (el.value !== msop2.article_id))) {
                article.disable().hide();
            }
        }
    },

    getPriceFields: function(type) {

        var fields = [];
        var disabled = type == 'update' ? true : false;

        var value = type == 'update' ? {
            xtype: 'textfield',
            name: 'value',
            readOnly: true,
            fieldLabel: _('msop2_value'),
            anchor: '99%',
            msgTarget: 'under',
            product_id: msop2.product_id
        } : {
            xtype: 'msop2-minishop2-combo-one-options',
            id: 'msop2-minishop2-combo-one-options-' + type,
            name: 'value',
            fieldLabel: _('msop2_value'),
            description: _('msop2_value_help'),
            emptyText: _('msop2_select_empty'),
            anchor: '99%',
            msgTarget: 'under',
            product_id: msop2.product_id,
            option_id: '1'
        };

        fields.push({
            xtype: 'hidden',
            name: 'id',
            id: 'msop2-product-price-id-' + type
        }, {
            xtype: 'hidden',
            name: 'product_id',
            id: 'msop2-product-product_id-' + type
        }, {
            xtype: 'msop2-combo-option',
            disabled: disabled,
            fieldLabel: _('msop2_key'),
            name: 'option',
            hiddenName: 'option',
            allowBlank: false,
            anchor: '99%',
            id: 'msop2-product-option-' + type,
            listeners: {
                afterrender: {
                    fn: function(r) {
                        this.handleHideOption(type);
                    },
                    scope: this
                },
                select: {
                    fn: function(r) {
                        this.handleChangeOption(type);
                    },
                    scope: this
                }
            }
        }, value, {
            xtype: 'msop2-combo-operation',
            fieldLabel: _('msop2_operation'),
            name: 'operation',
            hiddenName: 'operation',
            allowBlank: false,
            anchor: '99%',
            id: 'msop2-product-operation-handle-' + type,
            listeners: {
                afterrender: {
                    fn: function(r) {
                        this.handleChangeOperation(type);
                    },
                    scope: this
                },
                select: {
                    fn: function(r) {
                        this.handleChangeOperation(type);
                    },
                    scope: this
                }
            }
        }, {
            xtype: 'textfield',
            maskRe: /[0123456789\.\-]/,
            fieldLabel: _('msop2_price'),
            name: 'price',
            hiddenName: 'price',
            allowBlank: false,
            anchor: '99%',
            id: 'msop2-product-price-text-' + type
        });

        if (MODx.config.msop2_show_count != 0) {
            fields.push({
                xtype: 'numberfield',
                fieldLabel: _('msop2_count'),
                name: 'count',
                hiddenName: 'count',
                allowBlank: true,
                anchor: '99%',
                id: 'msop2-product-price-count-' + type
            });
        }
        if (MODx.config.msop2_show_weight != 0) {
            fields.push({
                xtype: 'numberfield',
                fieldLabel: _('msop2_weight'),
                name: 'weight',
                hiddenName: 'weight',
                allowBlank: true,
                anchor: '99%',
                id: 'msop2-product-price-weight-' + type
            });
        }
        if (MODx.config.msop2_show_article != 0) {
            fields.push({
                xtype: 'textfield',
                fieldLabel: _('msop2_article'),
                name: 'article',
                hiddenName: 'weight',
                allowBlank: true,
                anchor: '99%',
                id: 'msop2-product-price-article-' + type
            });
        }
        fields.push({
            xtype: 'xcheckbox',
            boxLabel: _('msop2_active'),
            name: 'active',
            id: 'msop2-product-option-active-' + type
        });
        if (disabled) {
            fields.push({
                xtype: 'hidden',
                name: 'option_',
                hiddenName: 'option_',
                id: 'msop2-product-option_-' + type
            });
        }

        return fields;
    },

    removePrice: function(btn, e) {
        if (this.menu.record) {
            MODx.msg.confirm({
                title: _('msop2_menu_remove'),
                text: _('msop2_menu_remove_confirm'),
                url: msop2.config.connector_url,
                params: {
                    action: 'mgr/price/remove',
                    id: this.menu.record.id
                },
                listeners: {
                    success: {
                        fn: function(r) {
                            this.refresh();
                        },
                        scope: this
                    }
                }
            });
        }
    },

    deleteSelected: function(btn, e) {
        var cs = this.getSelectedAsList();
        if (cs === false) return false;

        MODx.msg.confirm({
            title: _('msop2_menu_remove'),
            text: _('msop2_menu_remove_multiple_confirm'),
            url: msop2.config.connector_url,
            params: {
                action: 'mgr/price/delete_multiple',
                ids: cs
            },
            listeners: {
                'success': {
                    fn: function(r) {
                        this.getSelectionModel().clearSelections(true);
                        this.refresh();
                    },
                    scope: this
                }
            }
        });

        return true;
    },

    activeSelected: function(btn, e) {
        var cs = this.getSelectedAsList();
        if (cs === false) return false;

        MODx.msg.confirm({
            title: _('msop2_menu_active'),
            text: _('msop2_menu_active_multiple_confirm'),
            url: msop2.config.connector_url,
            params: {
                action: 'mgr/price/active_multiple',
                ids: cs,
                value: 1
            },
            listeners: {
                'success': {
                    fn: function(r) {
                        this.getSelectionModel().clearSelections(true);
                        this.refresh();
                    },
                    scope: this
                }
            }
        });

        return true;
    },

    inactiveSelected: function(btn, e) {
        var cs = this.getSelectedAsList();
        if (cs === false) return false;

        MODx.msg.confirm({
            title: _('msop2_menu_inactive'),
            text: _('msop2_menu_inactive_multiple_confirm'),
            url: msop2.config.connector_url,
            params: {
                action: 'mgr/price/active_multiple',
                ids: cs,
                value: 0
            },
            listeners: {
                'success': {
                    fn: function(r) {
                        this.getSelectionModel().clearSelections(true);
                        this.refresh();
                    },
                    scope: this
                }
            }
        });

        return true;
    },

    setValueSelected: function(btn, e, field, value) {
        var cs = this.getSelectedAsList();
        if (cs === false) return false;

        var r = {
            ids: cs
        };
        if (this.setValueWindow) {
            try {
                this.setValueWindow.close();
                this.setValueWindow.destroy();
                this.setValueWindow = undefined;
            } catch (e) {}
        }
        if (!this.setValueWindow) {
            this.setValueWindow = MODx.load({
                xtype: 'msop2-window-price-set-value',
                record: r,
                listeners: {
                    'success': {
                        fn: function(r) {
                            this.getSelectionModel().clearSelections(true);
                            this.refresh();
                        },
                        scope: this
                    }
                }
            });
        }
        this.setValueWindow.setValues(r);
        this.setValueWindow.show(e.target);
        return true;
    },

    createAll: function(btn, e) {
        var product_id = btn.scope.config.product_id;

        if (this.createAllWindow) {
            try {
                this.createAllWindow.close();
                this.createAllWindow.destroy();
                this.createAllWindow = undefined;
            } catch (e) {}
        }
        if (!this.createAllWindow) {
            this.createAllWindow = MODx.load({
                xtype: 'msop2-window-price-create-all',
                listeners: {
                    'success': {
                        fn: function(r) {
                            this.refresh();
                        },
                        scope: this
                    }
                }
            });
        }
        this.createAllWindow.setValues({
            product_id: product_id,
            operation: 1,
            value: 0
        });
        this.createAllWindow.show(e.target);
        return true;
    }

});
Ext.reg('msop2-product-prices-grid', msop2.grid.Price);


msop2.window.CreatePrice = function(config) {
    config = config || {};
    this.ident = config.ident || 'meuitem' + Ext.id();
    Ext.applyIf(config, {
        title: _('msop2_menu_create'),
        id: this.ident,
        width: 600,
        autoHeight: true,
        labelAlign: 'left',
        labelWidth: 180,
        url: msop2.config.connector_url,
        action: 'mgr/price/create',
        fields: config.fields,
        keys: [{
            key: Ext.EventObject.ENTER,
            shift: true,
            fn: function() {
                this.submit()
            },
            scope: this
        }]
    });
    msop2.window.CreatePrice.superclass.constructor.call(this, config);
};
Ext.extend(msop2.window.CreatePrice, MODx.Window);
Ext.reg('msop2-window-price-create', msop2.window.CreatePrice);


msop2.window.UpdatePrice = function(config) {
    config = config || {};
    this.ident = config.ident || 'meuitem' + Ext.id();
    Ext.applyIf(config, {
        title: _('msop2_menu_update'),
        id: this.ident,
        width: 600,
        autoHeight: true,
        labelAlign: 'left',
        labelWidth: 180,
        url: msop2.config.connector_url,
        action: 'mgr/price/update',
        fields: config.fields,
        keys: [{
            key: Ext.EventObject.ENTER,
            shift: true,
            fn: function() {
                this.submit()
            },
            scope: this
        }]
    });
    msop2.window.UpdatePrice.superclass.constructor.call(this, config);
};
Ext.extend(msop2.window.UpdatePrice, MODx.Window);
Ext.reg('msop2-window-price-update', msop2.window.UpdatePrice);


/*------------------------------------------------------*/
msop2.window.SetValue = function(config) {
    config = config || {};

    var type = 'update';

    Ext.applyIf(config, {
        id: 'msop2-window-price-set-value-' + type,
        title: _('msop2_menu_set'),
        url: msop2.config.connector_url,
        baseParams: {
            action: 'mgr/price/setprice_multiple'
        },
        width: 600,
        autoHeight: true,
        labelAlign: 'left',
        labelWidth: 180,
        fields: this.getFields('update')

    });
    msop2.window.SetValue.superclass.constructor.call(this, config);
};
Ext.extend(msop2.window.SetValue, MODx.Window, {

    handleChangeOperation: function(type) {
        var el = Ext.getCmp('msop2-product-operation-handle-set-' + type);
        var price = Ext.getCmp('msop2-product-price-text-set-' + type);

        switch (el.value) {
            case 1:
            case '1':
            {
                price.maskRe = /[0123456789\.\-]/;

                break;
            }
            case 2:
            case 3:
            case '2':
            case '3':
            {
                price.maskRe = /[0123456789\.\-%]/;

                break;
            }
        }
    }

    ,
    getFields: function(type) {

        var fields = [];

        fields.push({
            xtype: 'hidden',
            name: 'ids'
        }, {
            xtype: 'textfield',
            maskRe: /[0123456789\.\-]/,
            fieldLabel: _('msop2_price'),
            name: 'value',
            hiddenName: 'value',
            allowBlank: false,
            anchor: '99%',
            id: 'msop2-product-price-text-set-' + type
        }, {
            xtype: 'msop2-combo-operation',
            fieldLabel: _('msop2_operation'),
            name: 'operation',
            hiddenName: 'operation',
            allowBlank: false,
            anchor: '99%',
            id: 'msop2-product-operation-handle-set-' + type,
            listeners: {
                afterrender: {
                    fn: function(r) {
                        this.handleChangeOperation(type);
                    },
                    scope: this
                },
                select: {
                    fn: function(r) {
                        this.handleChangeOperation(type);
                    },
                    scope: this
                }
            }
        });

        return fields;
    }

});
Ext.reg('msop2-window-price-set-value', msop2.window.SetValue);


/*------------------------------------------------------*/
msop2.window.CreateAll = function(config) {
    config = config || {};
    var type = 'createall';
    Ext.applyIf(config, {
        id: 'msop2-window-price-create-all-' + type,
        title: _('msop2_price_create_all'),
        url: msop2.config.connector_url,
        baseParams: {
            action: 'mgr/price/create_all'
        },
        width: 600,
        autoHeight: true,
        labelAlign: 'left',
        labelWidth: 180,
        fields: this.getFields(type)

    });
    msop2.window.CreateAll.superclass.constructor.call(this, config);
};
Ext.extend(msop2.window.CreateAll, MODx.Window, {

    handleChangeOperation: function(type) {
        var el = Ext.getCmp('msop2-product-operation-handle-set-' + type);
        var price = Ext.getCmp('msop2-product-price-text-set-' + type);

        switch (el.value) {
            case 1:
            case '1':
            {
                price.maskRe = /[0123456789\.\-]/;

                break;
            }
            case 2:
            case 3:
            case '2':
            case '3':
            {
                price.maskRe = /[0123456789\.\-%]/;

                break;
            }
        }
    },

    getFields: function(type) {

        var fields = [];

        fields.push({
            xtype: 'hidden',
            name: 'product_id'
        }, {
            xtype: 'msop2-combo-option',
            fieldLabel: _('msop2_key'),
            name: 'option',
            hiddenName: 'option',
            allowBlank: true,
            anchor: '99%',
            id: 'msop2-product-option-' + type
        }, {
            xtype: 'textfield',
            maskRe: /[0123456789\.\-]/,
            fieldLabel: _('msop2_price'),
            name: 'value',
            hiddenName: 'value',
            allowBlank: false,
            anchor: '99%',
            id: 'msop2-product-price-text-set-' + type
        }, {
            xtype: 'msop2-combo-operation',
            fieldLabel: _('msop2_operation'),
            name: 'operation',
            hiddenName: 'operation',
            allowBlank: false,
            anchor: '99%',
            id: 'msop2-product-operation-handle-set-' + type,
            listeners: {
                afterrender: {
                    fn: function(r) {
                        this.handleChangeOperation(type);
                    },
                    scope: this
                },
                select: {
                    fn: function(r) {
                        this.handleChangeOperation(type);
                    },
                    scope: this
                }
            }
        });

        return fields;
    }

});
Ext.reg('msop2-window-price-create-all', msop2.window.CreateAll);
