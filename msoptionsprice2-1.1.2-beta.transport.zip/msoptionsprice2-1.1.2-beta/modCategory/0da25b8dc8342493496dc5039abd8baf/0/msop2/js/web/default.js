var msop2 = {
    par: {},

    setup: function() {
        msop2.par.msform = '.ms2_form';
        msop2.par.product = '.msop2.product-';
        msop2.par.product_weight = '.msop2.product_weight-';
        msop2.par.product_old_price = '.msop2.product_old_price-';
        msop2.par.product_article = '.msop2.product_article-';
        msop2.par.exclude = ['count'];
    },

    initialize: function() {
        msop2.setup();
        // jQuery
        if (typeof jQuery === 'undefined') {
            document.write('<script src="' + msop2Config.jsUrl + 'web/lib/jquery.min.js"><\/script>');
        }
        // listeners
        $(document).on('change', msop2.par.msform, function(e) {
            var t = $(e.target);
            var nt = $(e.target).attr('name');
            if ($.inArray(nt, msop2.par.exclude) > -1) {
                return false;
            }
            msop2.price.get(this);
        });
        // ready
        $(document).ready(function() {
            var $this = $(msop2.par.msform);
            msop2.price.get($this);
        });
    },

    price: {
        get: function(self) {
            var $this = $(self);
            var formData = $this.serializeArray();
            var options = {};
            $.each(formData, function(key, value) {
                options[value.name.replace('[', '.').replace(']', '')] = value.value;
            });
            msop2.Send.options('price/get', options);
        },

        change: function(data) {
            if (!data) {
                return;
            }
            var product = $(msop2.par.product + data.id);
            product.html(data.price);
        }
    },

    old_price: {
        change: function(data) {
            if (!data) {
                return;
            }
            var price = $(msop2.par.product + data.id);
            var old_price = $(msop2.par.product_old_price + data.id);
            if (old_price && price) {
                old_price.html(price.html());
            }
        }
    },

    weight: {
        change: function(data) {
            if (!data) {
                return;
            }
            var weight = $(msop2.par.product_weight + data.id);
            weight.html(data.weight);
        }
    },

    article: {
        change: function(data) {
            if (!data) {
                return;
            }
            var article = $(msop2.par.product_article + data.id);
            article.html(data.article);
        }
    }

};

msop2.Send = {
    options: function(action, data) {
        $.post(msop2Config.webconnector, {
            action: action,
            data: data
        }, function(response) {
            if (response.success) {
                msop2.old_price.change(response.data);
                msop2.price.change(response.data);
                msop2.weight.change(response.data);
                msop2.article.change(response.data);
            } else {}
        }, 'json');
    }
};

msop2.initialize();
