--------------------
msGiftsRuSynch
--------------------
Author: Pavel Gvozdb <pa6ok.ru>
--------------------

Компонент синхронизации выгрузки с gifts.ru в формате XML с сайтом на MODX Revolution + minishop2 + msop2.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/gvozdb/msGiftsRuSynch/issues