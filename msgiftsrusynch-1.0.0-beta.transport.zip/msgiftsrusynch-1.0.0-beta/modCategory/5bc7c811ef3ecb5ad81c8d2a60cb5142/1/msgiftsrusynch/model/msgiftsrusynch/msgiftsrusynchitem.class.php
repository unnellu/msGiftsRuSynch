<?php

/**
 * @package modextra
 */
class msGiftsRuSynchItem extends xPDOSimpleObject {
}