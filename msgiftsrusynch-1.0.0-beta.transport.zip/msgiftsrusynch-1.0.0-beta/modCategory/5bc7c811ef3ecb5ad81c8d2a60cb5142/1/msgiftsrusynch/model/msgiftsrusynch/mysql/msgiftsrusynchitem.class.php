<?php
require_once (dirname(dirname(__FILE__)) . '/msgiftsrusynchitem.class.php');
class msGiftsRuSynchItem_mysql extends msGiftsRuSynchItem {}